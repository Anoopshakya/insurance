# Phase 1 — Foundation: Setup Instructions

This folder has two parts:
- `supabase/migrations/` — 12 SQL files, run in order, build the entire DB from the Phase 0 ERD.
- `app-scaffold/` — the Next.js project skeleton with auth + RBAC wired end-to-end.

I can't run `npm install` or hit Supabase/Firebase from here (no network
access in this environment), so these steps are what you run locally.

## Step 1 — Create the Supabase project

1. Go to supabase.com, create a new project.
2. Get your Project URL, anon key, and service_role key from Project Settings > API.
3. In the SQL Editor, run each file in `supabase/migrations/` **in numeric
   order, 001 through 012**. They have foreign-key dependencies on each
   other (e.g. `007_referrals.sql` alters the `leads` table created in
   `003_crm.sql`), so order matters.
4. Verify: `select count(*) from role_permissions;` should return a
   non-zero number — confirms the RBAC seed ran.

Alternative: if you have the Supabase CLI installed, `supabase db push`
after placing these files in your project's `supabase/migrations` folder
does the same thing.

## Step 2 — Create the Firebase project

1. Go to the Firebase console, create a project.
2. Enable Authentication > Sign-in method: Email/Password, and Phone.
3. For Admin portal users, enable Multi-Factor Authentication in the
   Authentication settings (SOW requires MFA for Admin).
4. Get the client config (apiKey, authDomain, projectId, appId) from
   Project Settings > General.
5. Generate a service account key (Project Settings > Service Accounts >
   Generate new private key) — this gives you the Admin SDK credentials.

## Step 3 — Set up the Next.js project

```bash
# copy app-scaffold/ contents into a new repo, then:
npm install
cp .env.example .env.local
# fill in .env.local with the Supabase + Firebase values from steps 1-2
npm run dev
```

## Step 4 — Understand the pattern before writing more routes

Open `src/app/api/agents/route.ts`. Every protected API route in this
project follows the same three-step shape:

1. `verifyRequestToken()` — confirms the request really comes from a
   logged-in Firebase user, not a client-supplied id.
2. `userHasPermission()` — checks the `role_permissions` table (seeded in
   migration 012) before allowing the action.
3. Only then touch Supabase via `supabaseServer()`, and if it's a mutation
   on a business-critical table, insert a row into `audit_logs`.

When you build `/api/leads`, `/api/policies`, `/api/commission/rules`,
etc. in later phases, copy this file's structure rather than inventing a
new pattern per route — that consistency is what keeps the audit trail
and RBAC actually reliable across 15+ modules.

## Step 5 — Confirm the network depth constraint works

Once agents exist, test the 3-level cap directly in the Supabase SQL editor:

```sql
-- should succeed: level 1, 2, 3
insert into agents (user_id, agent_code, sponsor_id) values (...);
-- attempting a 4th level should raise:
-- "Network depth limit exceeded: max 3 levels allowed"
```

If that exception doesn't fire correctly, the trigger in
`002_agents_network.sql` needs adjustment before you build anything on
top of the network module — this constraint is load-bearing for the
entire commission engine.

## What's intentionally NOT in this scaffold yet

- No UI components yet (Phase 3+).
- No commission calculation service (Phase 7) — the schema supports it,
  the logic doesn't exist yet.
- No RLS (Row Level Security) policies on Supabase tables yet — this
  scaffold currently relies on the service-role key + app-layer RBAC
  checks. Decide before Phase 3 whether you also want RLS as a second
  layer of defense (recommended for a financial app, but adds
  complexity — worth a deliberate decision, not a default).
